
		<footer class="page-footer orange">
			<div class="container">
				<div class="row">
					<div class="col l6 s12">
						<h5 class="white-text">This site uses</h5>
						<p class="grey-text text-lighten-4">MaterializeCSS for ...</p>


					</div>
					<div class="col l3 s12">
						<h5 class="white-text">Links</h5>
						<ul>
							<li><a class="white-text" href="index.php">Bookmark</a></li>
							<li><a class="white-text" href="../part2/index.php">Part 2</a></li>
						</ul>
					</div>
					<div class="col l3 s12">
						<h5 class="white-text">Connect</h5>
						<ul>
							<li><a class="white-text" href="#!">Link 1</a></li>
							<li><a class="white-text" href="#!">Link 2</a></li>
							<li><a class="white-text" href="#!">Link 3</a></li>
							<li><a class="white-text" href="#!">Link 4</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="footer-copyright">
				<div class="container">
					Made by <a class="orange-text text-lighten-3" href="http://www.arjunkalburgi.com">Arjun</a>
				</div>
			</div>
		</footer>


		<script src="assets/jquery.min.js"></script>
		<script src="assets/materialize.min.js"></script>
	    
	</body>
</html>
