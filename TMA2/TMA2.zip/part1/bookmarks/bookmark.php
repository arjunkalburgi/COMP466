
<?php
	is_logged_in();
?>

<div class="index_splash">
	<h1 class="header_text">Welcome To Bookmarking!</h1>
</div>

<?php
    include 'bookmarks/update_bookmarks.php';
    include 'bookmarks/create_bookmarks.php';
?>

