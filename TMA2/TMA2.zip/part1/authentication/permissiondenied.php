<p class="error">
	Cannot view this content without logging in. 
</p>
<?php include 'authentication/login.php' ?>