/*!
 * Clientside JavaScript for COMP390 Ass1Prt2
 * Copyright 2014-2017 Materialize
 * MIT License (https://raw.githubusercontent.com/Dogfalo/materialize/master/LICENSE)
 */
