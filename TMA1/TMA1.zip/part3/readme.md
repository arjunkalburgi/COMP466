# todo

[x] - There should be a button to start/stop the show;
[x] - There should be a control to toggle the show between random and sequential;

[x] - The data of the images should be in a JSON array so that images and their captions can be easily maintained;
[x] - There should be a caption for each image in the show;

[ ] - There should be a dropdown list for users to select different transition/transformation effects for the show;

[x] - There should be buttons to manually turn the show backward or forward, only if the show is in sequential mode;
